import tempfile
from ifnude import detect

def convert_to_sd(img):
    shapes = []
tempfile.NamedTemporaryFile(delete=False, suffix=".png")]
